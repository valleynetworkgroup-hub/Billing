<?php
/* Smarty version 4.5.3, created on 2025-12-07 16:19:03
  from '/home/vol8_4/ezyro.com/ezyro_40005848/htdocs/ui/ui/admin/port/add.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.5.3',
  'unifunc' => 'content_693538772df7d5_81473366',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '94980760971c600acb046e812c4d509f34cf1d61' => 
    array (
      0 => '/home/vol8_4/ezyro.com/ezyro_40005848/htdocs/ui/ui/admin/port/add.tpl',
      1 => 1765092698,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
    'file:sections/header.tpl' => 1,
    'file:sections/footer.tpl' => 1,
  ),
),false)) {
function content_693538772df7d5_81473366 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_subTemplateRender("file:sections/header.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

<div class="row">
	<div class="col-sm-12 col-md-12">
		<div class="panel panel-primary panel-hovered panel-stacked mb30">
			<div class="panel-heading"><?php echo Lang::T('Add Port Pool');?>
</div>
			<div class="panel-body">
				<form class="form-horizontal" method="post" role="form" action="<?php echo Text::url('');?>
pool/add-port-post">
					<div class="form-group">
						<label class="col-md-2 control-label"><?php echo Lang::T('Port Name');?>
</label>
						<div class="col-md-6">
							<input type="text" class="form-control" id="name" name="name" placeholder="Vpn Tunnel">
						</div>
					</div>
					<div class="form-group">
						<label class="col-md-2 control-label"><?php echo Lang::T('Public IP');?>
</label>
						<div class="col-md-6">
							<input type="text" class="form-control" id="public_ip" name="public_ip"
								placeholder="12.34.56.78">
						</div>
					</div>
					<div class="form-group">
						<label class="col-md-2 control-label"><?php echo Lang::T('Range Port');?>
</label>
						<div class="col-md-6">
							<input type="text" class="form-control" id="port_range" name="port_range"
								placeholder="	3000-8000">
						</div>
					</div>
					<div class="form-group">
						<label class="col-md-2 control-label"><a
								href="<?php echo Text::url('');?>
routers/add"><?php echo Lang::T('Routers');?>
</a></label>
						<div class="col-md-6">
							<select id="routers" name="routers" class="form-control select2">
								<?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['r']->value, 'rs');
$_smarty_tpl->tpl_vars['rs']->do_else = true;
if ($_from !== null) foreach ($_from as $_smarty_tpl->tpl_vars['rs']->value) {
$_smarty_tpl->tpl_vars['rs']->do_else = false;
?>
									<option value="<?php echo $_smarty_tpl->tpl_vars['rs']->value['name'];?>
"><?php echo $_smarty_tpl->tpl_vars['rs']->value['name'];?>
</option>
								<?php
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
							</select>
						</div>
					</div>
					<div class="form-group">
						<div class="col-lg-offset-2 col-lg-10">
							<button class="btn btn-primary"
								onclick="return ask(this, '<?php echo Lang::T("Continue the process of adding Ports?");?>
')"
								type="submit"><?php echo Lang::T('Save');?>
</button>
							Or <a href="<?php echo Text::url('');?>
pool/port"><?php echo Lang::T('Cancel');?>
</a>
						</div>
					</div>
				</form>

			</div>
		</div>
	</div>
</div>

<?php $_smarty_tpl->_subTemplateRender("file:sections/footer.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
}
}
