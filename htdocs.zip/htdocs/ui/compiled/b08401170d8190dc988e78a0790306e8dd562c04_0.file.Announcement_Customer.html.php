<?php
/* Smarty version 4.5.3, created on 2025-12-07 16:26:50
  from '/home/vol8_4/ezyro.com/ezyro_40005848/htdocs/pages/Announcement_Customer.html' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.5.3',
  'unifunc' => 'content_69353a4abe8ff6_64193307',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'b08401170d8190dc988e78a0790306e8dd562c04' => 
    array (
      0 => '/home/vol8_4/ezyro.com/ezyro_40005848/htdocs/pages/Announcement_Customer.html',
      1 => 1765092678,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_69353a4abe8ff6_64193307 (Smarty_Internal_Template $_smarty_tpl) {
?>Pengumuman Pelanggan!!<br>
Besok libur<br>
<br>
Customer Announcement!!<br>
Tomorrow holiday<br>
<br>
<br>
This Announcement is for Customer Dashboard<?php }
}
