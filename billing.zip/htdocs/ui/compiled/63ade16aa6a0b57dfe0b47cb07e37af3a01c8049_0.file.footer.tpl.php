<?php
/* Smarty version 4.5.3, created on 2025-12-07 14:40:46
  from '/home/vol8_4/ezyro.com/ezyro_40005848/htdocs/ui/ui/sections/footer.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.5.3',
  'unifunc' => 'content_69352f7ed5c898_82294347',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '63ade16aa6a0b57dfe0b47cb07e37af3a01c8049' => 
    array (
      0 => '/home/vol8_4/ezyro.com/ezyro_40005848/htdocs/ui/ui/sections/footer.tpl',
      1 => 1765092700,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
    'file:admin/footer.tpl' => 1,
  ),
),false)) {
function content_69352f7ed5c898_82294347 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_subTemplateRender("file:admin/footer.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
}
}
