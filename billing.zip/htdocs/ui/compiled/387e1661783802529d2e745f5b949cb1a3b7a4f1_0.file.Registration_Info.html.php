<?php
/* Smarty version 4.5.3, created on 2025-12-07 16:16:15
  from '/home/vol8_4/ezyro.com/ezyro_40005848/htdocs/pages/Registration_Info.html' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.5.3',
  'unifunc' => 'content_693537cf046d51_40851400',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '387e1661783802529d2e745f5b949cb1a3b7a4f1' => 
    array (
      0 => '/home/vol8_4/ezyro.com/ezyro_40005848/htdocs/pages/Registration_Info.html',
      1 => 1765092678,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_693537cf046d51_40851400 (Smarty_Internal_Template $_smarty_tpl) {
?>Before you registered, you must Buy Voucher first<br><br>
Sebelum mendaftar pastikan anda membeli voucher terlebih dahulu<?php }
}
