<?php
/* Smarty version 4.5.3, created on 2025-12-07 16:32:38
  from '/home/vol8_4/ezyro.com/ezyro_40005848/htdocs/system/plugin/ui/recharge_cards.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.5.3',
  'unifunc' => 'content_69353ba65e7491_56156668',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'eb6795224dc167d13c591016c996c19b07c4c64e' => 
    array (
      0 => '/home/vol8_4/ezyro.com/ezyro_40005848/htdocs/system/plugin/ui/recharge_cards.tpl',
      1 => 1741255378,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
    'file:sections/header.tpl' => 1,
    'file:sections/footer.tpl' => 1,
  ),
),false)) {
function content_69353ba65e7491_56156668 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_subTemplateRender("file:sections/header.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>
<style>
    /* Styles for overall layout and responsiveness */
    body {
        background-color: #f8f9fa;
        font-family: 'Arial', sans-serif;
        padding: 0;
        margin: 0;
    }

    .container {
        margin-top: 20px;
        background-color: #d8dfe5;
        border-radius: 8px;
        box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        padding: 20px;
        max-width: 98%;
        overflow-x: auto;
        flex-wrap: wrap;
        justify-content: space-between;
        align-items: center;
    }

    /* Styles for table and pagination */
    .table {
        width: 100%;
        margin-bottom: 1rem;
        background-color: #fff;
        box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
    }

    .table th {
        vertical-align: middle;
        border-color: #dee2e6;
        background-color: #343a40;
        color: #fff;
    }

    .table td {
        vertical-align: middle;
        border-color: #dee2e6;
    }

    .table-striped tbody tr:nth-of-type(odd) {
        background-color: rgba(0, 0, 0, 0.05);
    }

    .table-hover tbody tr:hover {
        background-color: rgba(0, 0, 0, 0.075);
        color: #333;
        font-weight: bold;
        transition: background-color 0.3s, color 0.3s;
    }

    .pagination .page-item .page-link {
        color: #007bff;
        background-color: #fff;
        border: 1px solid #dee2e6;
        margin: 0 2px;
        padding: 6px 12px;
        transition: background-color 0.3s, color 0.3s;
    }

    .pagination .page-item .page-link:hover {
        background-color: #e9ecef;
        color: #0056b3;
    }

    .pagination .page-item.active .page-link {
        z-index: 1;
        color: #fff;
        background-color: #007bff;
        border-color: #007bff;
    }

    .dataTables_wrapper .dataTables_paginate .paginate_button {
        display: inline-block;
        padding: 5px 10px;
        margin-right: 5px;
        border: 1px solid #ccc;
        background-color: #fff;
        color: #333;
        cursor: pointer;
    }
</style>


<!-- <div class="btn-group pull-left">
    <button class="btn btn-success btn-xs" data-toggle="modal" data-target="#settings" title="General Settings"><span
         class="glyphicon glyphicon-cog" aria-hidden="true"></span> <?php echo Lang::T('Settings');?>
</button>
</div> -->
<!-- card -->
<div class="row" style="padding: 5px">
    <div class="col-lg-3 col-lg-offset-9">
        <div class="btn-group btn-group-justified" role="group">
            <div class="btn-group" role="group">
                <a href="#" class="btn btn-primary" data-toggle="modal" data-target="#create"><i
                        class="ion ion-android-add"></i>
                    <?php echo Lang::T('Generate Cards');?>
</a>
            </div>
            <div class="btn-group" role="group">
                <a href="<?php echo $_smarty_tpl->tpl_vars['_url']->value;?>
plugin/recharge_cardsPrint" target="print_card" class="btn btn-info"><i
                        class="ion ion-android-print"></i> <?php echo Lang::T('Print All');?>
</a>
            </div>
        </div>
    </div>
</div>
<div class="panel panel-hovered mb20 panel-primary">
    <div class="panel-heading">
        <!-- <?php if (in_array($_smarty_tpl->tpl_vars['_admin']->value['user_type'],array('SuperAdmin','Admin'))) {?>
        <div class="btn-group pull-right">
            <a class="btn btn-danger btn-xs" title="Remove used card" href="<?php echo $_smarty_tpl->tpl_vars['_url']->value;?>
plugin/hotspot_card"
                onclick="return confirm('Delete all used card code?')"><span class="glyphicon glyphicon-trash"
                    aria-hidden="true"></span> Delete All</a>
        </div>
        <?php }?> -->
        &nbsp;
    </div>


    <div class="container">
        <table id="datatable" class="table table-bordered table-striped table-condensed">
            <thead>
                <tr>
                    <th><input type="checkbox" id="select-all"></th>
                    <th><?php echo Lang::T('Card PIN');?>
</th>
                    <th><?php echo Lang::T('Card Price');?>
</th>
                    <th><?php echo Lang::T('Card Status');?>
</th>
                    <th><?php echo Lang::T('Card Serial No');?>
</th>
                    <th><?php echo Lang::T('Created Date');?>
</th>
                    <th><?php echo Lang::T('Generated By');?>
</th>
                    <th><?php echo Lang::T('Used Date');?>
</th>
                    <th><?php echo Lang::T('Used By');?>
</th>
                    <th><?php echo Lang::T('Manage');?>
</th>
                </tr>
            </thead>
            <tbody>
                <?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['cards']->value, 'card');
$_smarty_tpl->tpl_vars['card']->do_else = true;
if ($_from !== null) foreach ($_from as $_smarty_tpl->tpl_vars['card']->value) {
$_smarty_tpl->tpl_vars['card']->do_else = false;
?>
                <tr>
                    <td><input type="checkbox" name="card_ids[]" value="<?php echo $_smarty_tpl->tpl_vars['card']->value['id'];?>
"></td>
                    <td style="background-color: black; color: black;"
                        onmouseleave="this.style.backgroundColor = 'black';"
                        onmouseenter="this.style.backgroundColor = 'white';">
                        <?php echo $_smarty_tpl->tpl_vars['card']->value['card_number'];?>

                    </td>
                    <td><?php echo $_smarty_tpl->tpl_vars['card']->value['value'];?>
</td>
                    <td>
                        <?php if ($_smarty_tpl->tpl_vars['card']->value['status'] == 'used') {?>
                        <span class="label label-danger"><?php echo Lang::T('Used');?>
</span>
                        <?php } else { ?>
                        <span class="label label-success"><?php echo Lang::T('Not Used');?>
</span>
                        <?php }?>
                    </td>
                    <td style="background-color: black; color: black;"
                        onmouseleave="this.style.backgroundColor = 'black';"
                        onmouseenter="this.style.backgroundColor = 'white';">
                        <?php echo $_smarty_tpl->tpl_vars['card']->value['serial_number'];?>

                    </td>
                    <td><?php echo $_smarty_tpl->tpl_vars['card']->value['created_at'];?>
</td>
                    <td><?php if ($_smarty_tpl->tpl_vars['card']->value['admin_name']) {?>
                        <a href="<?php echo $_smarty_tpl->tpl_vars['_url']->value;?>
settings/users-view/<?php echo $_smarty_tpl->tpl_vars['card']->value['generated_by'];?>
"><?php echo $_smarty_tpl->tpl_vars['card']->value['admin_name'];?>
</a>
                        <?php } else { ?> -
                        <?php }?>
                    </td>
                    <td><?php echo $_smarty_tpl->tpl_vars['card']->value['used_at'];?>
</td>
                    <td><?php if ($_smarty_tpl->tpl_vars['card']->value['used_by'] == '0') {?>
                        <?php echo Lang::T('None');?>

                        <?php } else { ?>
                        <a href="<?php echo $_smarty_tpl->tpl_vars['_url']->value;?>
customers/view/<?php echo $_smarty_tpl->tpl_vars['card']->value['customer_id'];?>
"><?php echo $_smarty_tpl->tpl_vars['card']->value['customer_name'];?>
</a>
                    </td>
                    <?php }?>
                    <td>
                        <?php if ($_smarty_tpl->tpl_vars['card']->value['status'] != 'used') {?>
                        <a href="<?php echo $_smarty_tpl->tpl_vars['_url']->value;?>
plugin/recharge_cards_print&card_id=<?php echo $_smarty_tpl->tpl_vars['card']->value['id'];?>
" id="<?php echo $_smarty_tpl->tpl_vars['card']->value['id'];?>
"
                            style="margin: 0px;"
                            class="btn btn-success btn-xs">&nbsp;&nbsp;<?php echo Lang::T('Print');?>
&nbsp;&nbsp;</a>
                        <?php }?>
                        <button type="button" class="btn btn-primary btn-xs send-card" data-id="<?php echo $_smarty_tpl->tpl_vars['card']->value['id'];?>
"
                            data-toggle="modal" data-target="#sendCardModal">
                            <i class="glyphicon glyphicon-send"></i> <?php echo Lang::T('Send');?>

                        </button>
                    </td>
                </tr>
                <?php
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
            </tbody>
        </table>
        <br>
        <div class="row" style="padding: 5px">
            <div class="col-lg-3 col-lg-offset-9">
                <div class="btn-group btn-group-justified" role="group">
                    <div class="btn-group" role="group">
                        <?php if (in_array($_smarty_tpl->tpl_vars['_admin']->value['user_type'],array('SuperAdmin','Admin'))) {?>
                        <button id="deleteSelectedCards" class="btn btn-danger"><?php echo Lang::T('Delete
                            Selected');?>
</button>
                        <?php }?>
                    </div>
                    <div class="btn-group" role="group">
                        <button id="printSelectedCards" class="btn btn-success"><?php echo Lang::T('Print
                            Selected');?>
</button>
                    </div>
                </div>
            </div>
        </div>
    </div>
    &nbsp;

</div>

<div class="modal fade" id="settings">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
                <h4 class="modal-title"> <?php echo Lang::T('Generate Settings');?>
</h4>
            </div>
            <div class="box-body">
                <div class="tab-pane">
                    <form class="form-horizontal" method="post" autocomplete="off" role="form" action="">
                        <div class="form-group">
                            <label class="col-md-2 control-label"><?php echo Lang::T('Enable Recharge');?>
</label>
                            <div class="col-md-6">
                                <label class="switch">
                                    <input type="checkbox" id="recharge_cards_mode" value="1" name="recharge_cards_mode"
                                        <?php if ($_smarty_tpl->tpl_vars['_c']->value['recharge_cards_mode'] == 1) {?>checked<?php }?>>
                                    <span class="slider"></span>
                                </label>
                            </div>
                        </div>
                        <div class="form-group" id="recharge-type-group">
                            <label class="col-md-2 control-label"><?php echo Lang::T('Recharge Notification');?>
</label>
                            <div class="col-md-6">
                                <select class="form-control" name="recharge_cards_notify" id="recharge_cards_notify">
                                    <option value="1" <?php if ($_smarty_tpl->tpl_vars['_c']->value['recharge_cards_notify'] == '1') {?>selected<?php }?>>
                                        <?php echo Lang::T('Enabled');?>
</option>
                                    <option value="0" <?php if ($_smarty_tpl->tpl_vars['_c']->value['recharge_cards_notify'] == '0') {?>selected<?php }?>>
                                        <?php echo Lang::T('Disabled');?>
</option>
                                </select>
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="col-md-2 control-label"><?php echo Lang::T('Enable Message');?>
</label>
                            <div class="col-md-6">
                                <label class="switch">
                                    <input type="checkbox" id="recharge_message" value="1" name="recharge_message" <?php if ($_smarty_tpl->tpl_vars['_c']->value['recharge_message'] == 1) {?>checked<?php }?>>
                                    <span class="slider"></span>
                                </label>
                            </div>
                        </div>
                        <div class="form-group" id="message-group">
                            <label class="col-md-2 control-label"><?php echo Lang::T('Send Via');?>
</label>
                            <div class="col-md-6">
                                <select class="form-control" name="recharge_message_via" id="recharge_message_via">
                                    <option value="sms" <?php if ($_smarty_tpl->tpl_vars['_c']->value['recharge'] == 'sms') {?>selected<?php }?>>
                                        <?php echo Lang::T('SMS');?>
</option>
                                    <option value="wa" <?php if ($_smarty_tpl->tpl_vars['_c']->value['recharge_message_via'] == 'wa') {?>selected<?php }?>>
                                        <?php echo Lang::T('WhatsApp');?>
</option>
                                    <option value="both" <?php if ($_smarty_tpl->tpl_vars['_c']->value['recharge_message_via'] == 'both') {?>selected<?php }?>>
                                        <?php echo Lang::T('Both');?>
</option>
                                </select>
                            </div>
                        </div>
                        <div class="form-group" id="message-content-group">
                            <label class="col-md-2 control-label"><?php echo Lang::T('Message');?>
</label>
                            <div class="col-md-6">
                                <textarea class="form-control" id="recharge_message_content"
                                    name="recharge_message_content"
                                    rows="6"><?php echo Lang::htmlspecialchars($_smarty_tpl->tpl_vars['_json']->value['']);?>
</textarea>
                            </div>
                            <p class="help-block col-md-4">
                                <b>[[login_code]]</b> - <?php echo Lang::T('will replace customer login code');?>
.<br>
                                <b>[[package]]</b> - <?php echo Lang::T('will replace customer package name');?>
.<br>
                                <b>[[expiry]]</b> - <?php echo Lang::T('will replace customer package expiry date');?>
.<br>
                                <b>[[company]]</b> - <?php echo Lang::T('will replace your Company Name');?>
.<br>
                            </p>
                        </div>
                        <div class="form-group" id="">
                            <label class="col-md-2 control-label"><?php echo Lang::T('Recharge Send Template');?>
</label>
                            <div class="col-md-6">
                                <textarea rows="8" name="recharge_send" id="recharge_send"
                                    class="form-control"><?php echo Lang::htmlspecialchars($_smarty_tpl->tpl_vars['_json']->value['']);?>
</textarea>
                            </div>
                            <p class="help-block col-md-4">
                                <b>[[code]]</b> - <?php echo Lang::T('will replace recharge code');?>
.<br>
                                <b>[[data]]</b> - <?php echo Lang::T('will replace recharge data limit');?>
.<br>
                                <b>[[validity]]</b> - <?php echo Lang::T('will replace recharge validity or duration');?>
.<br>
                                <b>[[company]]</b> - <?php echo Lang::T('will replace your Company Name');?>
.<br>
                            </p>
                        </div>

                        <div class="form-group" id="">
                            <label class="col-md-2 control-label"><?php echo Lang::T('Recharge Cards Print Template');?>
</label>
                            <div class="col-md-6">
                                <textarea rows="8" name="" id=""
                                    class="form-control"><?php echo Lang::htmlspecialchars($_smarty_tpl->tpl_vars['_json']->value['']);?>
</textarea>
                            </div>
                            <p class="help-block col-md-4">
                                <b>[[currency]]</b> - <?php echo Lang::T('will replace recharge currency code');?>
.<br>
                                <b>[[plan_price]]</b> - <?php echo Lang::T('will replace recharge plan price');?>
.<br>
                                <b>[[code]]</b> - <?php echo Lang::T('will replace recharge code');?>
.<br>
                                <b>[[data]]</b> - <?php echo Lang::T('will replace recharge data limit');?>
.<br>
                                <b>[[validity]]</b> - <?php echo Lang::T('will replace recharge validity or duration');?>
.<br>
                                <b>[[url]]</b> - <?php echo Lang::T('will replace recharge with recharge login url');?>
.<br>
                                <b>[[qrcode]]</b> - <?php echo Lang::T('will replace recharge QRcode');?>
.<br>
                            </p>
                        </div>
                        <div class="panel-body">
                            <div class="form-group">
                                <button class="btn btn-success btn-block" name="save" value="save" type="submit">
                                    <?php echo Lang::T('Save Changes');?>

                                </button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>



<div class="panel panel-hovered mb20 panel-primary">
    <div class="panel-heading">
        <?php echo Lang::T('Locked Out Customers');?>

        &nbsp;
    </div>

    <div class="container">
        <table id="locktable" class="table table-bordered table-striped table-condensed">
            <thead>
                <tr>
                    <!-- <th><input type="checkbox" id="select-all"></th> -->
                    <th><?php echo Lang::T('Customer Name');?>
</th>
                    <th><?php echo Lang::T('Failed Attempts');?>
</th>
                    <th><?php echo Lang::T('Last Attempt');?>
</th>
                    <th><?php echo Lang::T('Locked Until');?>
</th>
                    <th><?php echo Lang::T('Manage');?>
</th>
                </tr>
            </thead>
            <tbody>
                <?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['lockouts']->value, 'lock');
$_smarty_tpl->tpl_vars['lock']->do_else = true;
if ($_from !== null) foreach ($_from as $_smarty_tpl->tpl_vars['lock']->value) {
$_smarty_tpl->tpl_vars['lock']->do_else = false;
?>
                <tr>
                    <!-- <td><input type="checkbox" name="lock_ids[]" value="<?php echo $_smarty_tpl->tpl_vars['lock']->value['id'];?>
"></td> -->
                    <td><a href="<?php echo $_smarty_tpl->tpl_vars['_url']->value;?>
customers/view/<?php echo $_smarty_tpl->tpl_vars['lock']->value['user_id'];?>
"><?php echo $_smarty_tpl->tpl_vars['lock']->value['customer_name'];?>
</a></td>
                    <td>
                        <?php if ($_smarty_tpl->tpl_vars['lock']->value['failed_attempts'] >= '5') {?>
                        <span class="label label-danger"><?php echo Lang::T('Locked Out');?>
</span>
                        <?php } else { ?>
                        <span class="label label-warning"><?php echo $_smarty_tpl->tpl_vars['lock']->value['failed_attempts'];?>
</span>
                        <?php }?>
                    </td>
                    <td><?php echo $_smarty_tpl->tpl_vars['lock']->value['last_attempt'];?>
</td>
                    <td><?php echo $_smarty_tpl->tpl_vars['lock']->value['locked_until'];?>
</td>

                    <td>
                        <a href="<?php echo $_smarty_tpl->tpl_vars['_url']->value;?>
plugin/recharge_cardsUnblock&id=<?php echo $_smarty_tpl->tpl_vars['lock']->value['user_id'];?>
" id="<?php echo $_smarty_tpl->tpl_vars['lock']->value['user_id'];?>
"
                            onclick="return confirm('<?php echo Lang::T(" Are You Sure?");?>
')" style="margin: 0px;"
                            class="btn btn-success btn-xs"><?php echo Lang::T('Unlock');?>
</a>
                    </td>
                </tr>
                <?php
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
            </tbody>
        </table>
        <br>
    </div>
    &nbsp;

</div>

<form id="printSelectedForm" method="POST" action="<?php echo $_smarty_tpl->tpl_vars['_url']->value;?>
plugin/recharge_cards_print">
    <input type="hidden" name="cardIds" id="cardIdsInput">
</form>

<div class="modal fade" id="create">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
                <h4 class="modal-title"> <?php echo Lang::T('Generate Cards');?>
</h4>
            </div>
            <div class="box-body">
                <div class="tab-pane">
                    <form action="" method="post" enctype="multipart/form-data" class="form-horizontal">
                        <div class="form-group">
                            <label for="inputExperience" class="col-sm-2 control-label"><?php echo Lang::T('No of
                                Cards');?>
</label>
                            <div class="col-sm-10">
                                <input type="text" class="form-control" name="number_of_cards" value="1">
                            </div>
                        </div>
                        <div class="form-group">
                            <label for="inputSkills" class="col-sm-2 control-label">
                                <?php echo Lang::T('PIN Length');?>
</label>
                            <div class="col-sm-10">
                                <input type="text" class="form-control" name="lengthcode" value="12">
                            </div>
                        </div>
                        <div class="form-group">
                            <label for="inputSkills" class="col-sm-2 control-label">
                                <?php echo Lang::T('Card Value');?>
</label>
                            <div class="col-sm-10">
                                <input type="card_value" class="form-control" name="card_value"
                                    placeholder="Recharge Amount" value="">
                            </div>
                        </div>
                        <div class="form-group">
                            <label for="inputSkills" class="col-sm-2 control-label"> <?php echo Lang::T('Print
                                Now');?>
</label>

                            <div class="col-sm-10">
                                <input type="checkbox" id="print_now" name="print_now" class="iCheck" value="1">
                            </div>
                        </div>
                        <div class="box-footer">
                            <div class="pull-right">
                                <button type="submit" value="Generate " class="btn btn-primary">
                                    <i class="fa fa-telegram">
                                    </i> <?php echo Lang::T('Generate');?>
</button>
                            </div>
                            <button type="button" data-dismiss="modal" class="btn btn-danger">
                                <i class="">
                                </i> <?php echo Lang::T('Cancel');?>
</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>




<!-- Send Card Modal HTML -->

<div class="modal fade" id="sendCardModal" tabindex="-1" role="dialog" aria-labelledby="sendCardLabel"
    aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
                <h4 class="modal-title" id="sendCardLabel"> <?php echo Lang::T('Send Card PIN');?>
</h4>
            </div>
            <div class="box-body">
                <div class="tab-pane">
                    <form action="<?php echo $_smarty_tpl->tpl_vars['_url']->value;?>
plugin/recharge_cards_sendCard" method="post" enctype="multipart/form-data"
                        class="form-horizontal">
                        <input type="hidden" id="cardId" name="cardId">
                        <div class="form-group">
                            <label for="phone_number" class="col-sm-2 control-label"><?php echo Lang::T('Phone No');?>
</label>
                            <div class="col-sm-10">
                                <input type="text" id="phone_number" name="phoneNumber"
                                    placeholder="<?php echo Lang::T('Enter the receiver phone number');?>
" class="form-control">
                            </div>
                        </div>
                        <div class="form-group">
                            <label for="method" class="col-sm-2 control-label"><?php echo Lang::T('Send Via');?>
</label>
                            <div class="col-sm-10">
                                <select name="method" id="method" class="form-control">
                                    <option value="sms"><?php echo Lang::T('SMS');?>
</option>
                                    <option value="wa"><?php echo Lang::T('WhatsApp');?>
</option>
                                    <option value="both"><?php echo Lang::T('Both');?>
</option>
                                </select>
                            </div>
                        </div>
                        <div class="box-footer">
                            <div class="pull-right">
                                <button type="submit" class="btn btn-primary">
                                    <i class="fa fa-telegram"></i> <?php echo Lang::T('Send Now');?>

                                </button>
                            </div>
                            <button type="button" data-dismiss="modal" class="btn btn-danger">
                                <i class=""></i> <?php echo Lang::T('Cancel');?>

                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>


<?php echo '<script'; ?>
 src="https://code.jquery.com/jquery-3.6.0.min.js"><?php echo '</script'; ?>
>
<?php echo '<script'; ?>
 src="https://cdn.datatables.net/1.11.3/js/jquery.dataTables.min.js"><?php echo '</script'; ?>
>
<?php echo '<script'; ?>
>
    // Select or deselect all checkboxes
    document.getElementById('select-all').addEventListener('change', function () {
        var checkboxes = document.querySelectorAll('input[name="card_ids[]"]');
        for (var checkbox of checkboxes) {
            checkbox.checked = this.checked;
        }
    });

    // Handle delete selected Cards
    document.getElementById('deleteSelectedCards').addEventListener('click', function () {
        var selectedCards = [];
        document.querySelectorAll('input[name="card_ids[]"]:checked').forEach(function (checkbox) {
            selectedCards.push(checkbox.value);
        });

        if (selectedCards.length > 0) {
            if (confirm('Are you sure you want to delete the selected cards?')) {
                var xhr = new XMLHttpRequest();
                xhr.open('POST', '<?php echo $_smarty_tpl->tpl_vars['_url']->value;?>
plugin/recharge_cards_delete', true);
                xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
                xhr.onload = function () {
                    if (xhr.status === 200) {
                        location.reload(); // Reload the page to reflect the changes
                    } else {
                        console.error('Failed to delete cards: ', xhr.responseText);
                    }
                };
                xhr.send('cardIds=' + JSON.stringify(selectedCards));
            }
        } else {
            alert('Please select at least one card to delete.');
        }
    });

    // Handle single card deletion
    document.querySelectorAll('.delete-card').forEach(function (button) {
        button.addEventListener('click', function () {
            var cardId = this.getAttribute('data-id');
            if (confirm('Are you sure you want to delete this card?')) {
                var xhr = new XMLHttpRequest();
                xhr.open('POST', '<?php echo $_smarty_tpl->tpl_vars['_url']->value;?>
plugin/recharge_cards_delete', true);
                xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
                xhr.onload = function () {
                    if (xhr.status === 200) {
                        location.reload(); // Reload the page to reflect the changes
                    } else {
                        console.error('Failed to delete card: ', xhr.responseText);
                    }
                };
                xhr.send('cardIds=' + JSON.stringify([cardId]));
            }
        });
    });
<?php echo '</script'; ?>
>
<?php echo '<script'; ?>
>
    const $q = jQuery.noConflict();

    $q(document).ready(function () {
        $q('#locktable').DataTable({
            "pagingType": "full_numbers",
            "order": [
                [1, 'desc']
            ]
        });
    });
<?php echo '</script'; ?>
>
<?php echo '<script'; ?>
>
    const $j = jQuery.noConflict();

    $j(document).ready(function () {
        $j('#datatable').DataTable({
            "pagingType": "full_numbers",
            "order": [
                [1, 'desc']
            ]
        });
    });
<?php echo '</script'; ?>
>
<?php echo '<script'; ?>
>
    document.getElementById('printSelectedCards').addEventListener('click', function () {
        var selectedCards = [];
        document.querySelectorAll('input[name="card_ids[]"]:checked').forEach(function (checkbox) {
            selectedCards.push(checkbox.value);
        });

        if (selectedCards.length > 0) {
            document.getElementById('cardIdsInput').value = JSON.stringify(selectedCards);
            document.getElementById('printSelectedForm').submit();
        } else {
            alert('Please select at least one card to print.');
        }
    });
<?php echo '</script'; ?>
>
<?php echo '<script'; ?>
>
    var $ = jQuery.noConflict();
    $(document).ready(function () {
        $('.send-card').on('click', function () {
            var cardId = $(this).data('id');
            console.log('card ID:', cardId);
            $('#sendCardModal').find('#cardId').val(cardId); // Corrected ID reference
        });
    });
<?php echo '</script'; ?>
>

<?php echo '<script'; ?>
>
    window.addEventListener('DOMContentLoaded', function () {
        var portalLink = "https://github.com/focuslinkstech";
        $('#version').html('Recharge Cards Plugin | Ver: 1.0 | by: <a href="' + portalLink + '">Focuslinks Tech</a>');
    });
<?php echo '</script'; ?>
>

<?php $_smarty_tpl->_subTemplateRender("file:sections/footer.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
}
}
