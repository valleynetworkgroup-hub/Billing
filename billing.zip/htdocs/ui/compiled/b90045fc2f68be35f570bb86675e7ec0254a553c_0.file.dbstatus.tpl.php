<?php
/* Smarty version 4.5.3, created on 2025-12-07 16:08:29
  from '/home/vol8_4/ezyro.com/ezyro_40005848/htdocs/ui/ui/admin/settings/dbstatus.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.5.3',
  'unifunc' => 'content_693535fd72ce35_28967035',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'b90045fc2f68be35f570bb86675e7ec0254a553c' => 
    array (
      0 => '/home/vol8_4/ezyro.com/ezyro_40005848/htdocs/ui/ui/admin/settings/dbstatus.tpl',
      1 => 1765092698,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
    'file:sections/header.tpl' => 1,
    'file:sections/footer.tpl' => 1,
  ),
),false)) {
function content_693535fd72ce35_28967035 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_subTemplateRender("file:sections/header.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

<div class="row">
    <div class="col-sm-7">
        <div class="panel panel-primary">
            <div class="panel-heading"><?php echo Lang::T('Backup Database');?>
</div>
            <form method="post" action="<?php echo Text::url('');?>
settings/dbbackup">
                <div class="table-responsive">
                    <table class="table table-bordered">
                        <thead>
                            <tr>
                                <th width="50%"><?php echo Lang::T('Table Name');?>
</th>
                                <th><?php echo Lang::T('Rows');?>
</th>
                                <th><?php echo Lang::T('Choose');?>
</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['tables']->value, 'tbl');
$_smarty_tpl->tpl_vars['tbl']->do_else = true;
if ($_from !== null) foreach ($_from as $_smarty_tpl->tpl_vars['tbl']->value) {
$_smarty_tpl->tpl_vars['tbl']->do_else = false;
?>
                                <tr>
                                    <td><?php echo $_smarty_tpl->tpl_vars['tbl']->value['name'];?>
</td>
                                    <td><?php echo $_smarty_tpl->tpl_vars['tbl']->value['rows'];?>
</td>
                                    <td><input type="checkbox" checked name="tables[]" value="<?php echo $_smarty_tpl->tpl_vars['tbl']->value['name'];?>
"></td>
                                </tr>
                            <?php
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
                        </tbody>
                    </table>
                </div>
                <div class="panel-body">
                    <div class="row">
                        <div class="col-md-6"><?php echo Lang::T('Don\'t select logs if it failed');?>
</div>
                        <div class="col-md-4 text-right">
                            <button type="submit" class="btn btn-primary btn-xs btn-block" aria-label="Download Backup Database">
                                <i class="fa fa-download"></i> <?php echo Lang::T('Download Backup Database');?>

                            </button>
                        </div>
                    </div>
                </div>
            </form>
        </div>
    </div>
    <div class="col-sm-5">
        <div class="panel panel-primary">
            <div class="panel-heading"><?php echo Lang::T('Restore Database');?>
</div>
            <form method="post" action="<?php echo Text::url('');?>
settings/dbrestore" enctype="multipart/form-data">
                <div class="panel-body">
                    <div class="row">
                        <div class="col-md-7"><input type="file" name="json" accept="application/json"></div>
                        <div class="col-md-5 text-right">
                            <button type="submit" class="btn btn-primary btn-block btn-xs" aria-label="Restore Database">
                                <i class="fa fa-upload"></i> <?php echo Lang::T('Restore Database');?>

                            </button>
                        </div>
                    </div>
                </div>
            </form>
            <div class="panel-footer"><?php echo Lang::T('Restoring the database will clean up data and then restore all the data.');?>
</div>
        </div>
    </div>
</div>

<?php $_smarty_tpl->_subTemplateRender("file:sections/footer.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
}
}
