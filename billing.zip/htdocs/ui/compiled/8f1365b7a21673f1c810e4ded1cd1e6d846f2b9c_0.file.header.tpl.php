<?php
/* Smarty version 4.5.3, created on 2025-12-07 16:26:59
  from '/home/vol8_4/ezyro.com/ezyro_40005848/htdocs/ui/ui/user-ui/header.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.5.3',
  'unifunc' => 'content_69353a5355dd64_79639199',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '8f1365b7a21673f1c810e4ded1cd1e6d846f2b9c' => 
    array (
      0 => '/home/vol8_4/ezyro.com/ezyro_40005848/htdocs/ui/ui/user-ui/header.tpl',
      1 => 1765092703,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
    'file:customer/header.tpl' => 1,
  ),
),false)) {
function content_69353a5355dd64_79639199 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_subTemplateRender("file:customer/header.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

<?php }
}
