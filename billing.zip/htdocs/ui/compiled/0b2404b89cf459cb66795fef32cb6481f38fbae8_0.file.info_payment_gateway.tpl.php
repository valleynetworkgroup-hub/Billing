<?php
/* Smarty version 4.5.3, created on 2025-12-07 14:34:05
  from '/home/vol8_4/ezyro.com/ezyro_40005848/htdocs/ui/ui/widget/info_payment_gateway.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.5.3',
  'unifunc' => 'content_69352dedc59089_73026612',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '0b2404b89cf459cb66795fef32cb6481f38fbae8' => 
    array (
      0 => '/home/vol8_4/ezyro.com/ezyro_40005848/htdocs/ui/ui/widget/info_payment_gateway.tpl',
      1 => 1765092703,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_69352dedc59089_73026612 (Smarty_Internal_Template $_smarty_tpl) {
?><div class="panel panel-success panel-hovered mb20 activities">
    <div class="panel-heading"><?php echo Lang::T('Payment Gateway');?>
: <?php echo str_replace(',',', ',$_smarty_tpl->tpl_vars['_c']->value['payment_gateway']);?>

    </div>
</div><?php }
}
