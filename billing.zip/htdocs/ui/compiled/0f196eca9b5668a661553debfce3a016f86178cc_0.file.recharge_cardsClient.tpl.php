<?php
/* Smarty version 4.5.3, created on 2025-12-07 16:26:59
  from '/home/vol8_4/ezyro.com/ezyro_40005848/htdocs/system/plugin/ui/recharge_cardsClient.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.5.3',
  'unifunc' => 'content_69353a535541d2_07521186',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '0f196eca9b5668a661553debfce3a016f86178cc' => 
    array (
      0 => '/home/vol8_4/ezyro.com/ezyro_40005848/htdocs/system/plugin/ui/recharge_cardsClient.tpl',
      1 => 1741255378,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
    'file:user-ui/header.tpl' => 1,
    'file:user-ui/footer.tpl' => 1,
  ),
),false)) {
function content_69353a535541d2_07521186 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_subTemplateRender("file:user-ui/header.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

<div class="row">
    <div class="col-md-8">
        <div class="box box-primary box-solid mb30">
            <div class="box-header">
                <h4 class="box-title"><?php echo Lang::T("Recharge a friend");?>
</h4>
            </div>
            <div class="box-body p-0">
                <form method="post" onsubmit="return askConfirm()" role="form" action="<?php echo $_smarty_tpl->tpl_vars['_url']->value;?>
plugin/recharge_cardsClientPost">
                    <div class="form-group">
                        <div class="col-sm-5">
                            <input type="text" id="username" name="username" class="form-control" required
                                placeholder="<?php echo Lang::T('Username');?>
">
                        </div>
                        <div class="col-sm-5">
                            <input type="number" id="card_number" name="card_number" autocomplete="off"
                                class="form-control" required placeholder="<?php echo Lang::T('Enter the Card PIN');?>
">
                        </div>
                        <div class="form-group col-sm-2" align="center">
                            <button class="btn btn-success btn-block" id="sendBtn" type="submit" name="recharge"
                                onclick="return confirm('<?php echo Lang::T(" Are You Sure?");?>
')"><i
                                    class="glyphicon glyphicon-send"></i></button>
                        </div>
                    </div>
                </form>
            </div>
            <div class="box-header">
                <h4 class="box-title"><?php echo Lang::T("Redeem Recharge Card");?>
</h4>
            </div>
            <div class="box-body p-0">
                <form method="post" role="form" action="<?php echo $_smarty_tpl->tpl_vars['_url']->value;?>
plugin/recharge_cardsClientPost">
                    <div class="form-group">
                        <div class="col-sm-10">
                            <div class="input-group">
                                <input type="text" class="form-control" id="card_number" name="card_number" value=""
                                    placeholder="<?php echo Lang::T('Enter the Card PIN');?>
">
                                <span class="input-group-btn">
                                    <a class="btn btn-default" href="<?php echo APP_URL;?>
/scan/?back=<?php echo urlencode($_smarty_tpl->tpl_vars['_url']->value);
echo urlencode("
                                        plugin/recharge_cardsClient&card=");?>
"><i class="glyphicon glyphicon-qrcode"></i></a>
                                </span>
                            </div>
                        </div>
                        <div class="form-group col-sm-2" align="center">
                            <button class="btn btn-success btn-block" type="submit" name="recharge"><i
                                    class="glyphicon glyphicon-send"></i></button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<?php $_smarty_tpl->_subTemplateRender("file:user-ui/footer.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
}
}
