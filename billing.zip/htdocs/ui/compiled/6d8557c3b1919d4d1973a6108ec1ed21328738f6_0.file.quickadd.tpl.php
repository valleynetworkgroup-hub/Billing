<?php
/* Smarty version 4.5.3, created on 2025-12-07 16:30:53
  from '/home/vol8_4/ezyro.com/ezyro_40005848/htdocs/system/plugin/ui/quickadd.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.5.3',
  'unifunc' => 'content_69353b3d08b432_14585092',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '6d8557c3b1919d4d1973a6108ec1ed21328738f6' => 
    array (
      0 => '/home/vol8_4/ezyro.com/ezyro_40005848/htdocs/system/plugin/ui/quickadd.tpl',
      1 => 1764888522,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
    'file:sections/header.tpl' => 1,
    'file:sections/footer.tpl' => 1,
  ),
),false)) {
function content_69353b3d08b432_14585092 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_subTemplateRender("file:sections/header.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

<form class="form-horizontal" method="post" role="form" action="<?php echo $_smarty_tpl->tpl_vars['_url']->value;?>
plugin/quickadd/add<?php if ($_smarty_tpl->tpl_vars['routes']->value['2'] == 'pppoe') {?>/pppoe<?php }?>"> 
    <div class="row">
        <div class="col-md-6">
            <div class="panel panel-primary panel-hovered panel-stacked mb30">
					<ul class="nav nav-tabs">
						<li role="presentation" <?php if ($_smarty_tpl->tpl_vars['routes']->value['2'] == '') {?>class="active"<?php }?>>
							<a href="<?php echo $_smarty_tpl->tpl_vars['_url']->value;?>
plugin/quickadd" aria-controls="plugin" style="border-radius: 20px 6px 0 0"><?php echo Lang::T('Hotspot');?>
</a></li>
						<li role="presentation" <?php if ($_smarty_tpl->tpl_vars['routes']->value['2'] == 'pppoe') {?>class="active"<?php }?>>
							<a href="<?php echo $_smarty_tpl->tpl_vars['_url']->value;?>
plugin/quickadd/pppoe"><?php echo Lang::T('PPPoE');?>
</a>
						</li>
					</ul>
                <div class="panel-heading"><?php echo Lang::T('Add New customer');?>
</div>
                <div class="panel-body">
				<input type="hidden" name="account_type" value="Hotspot">
                    <div class="form-group">
                        <label class="col-md-3 control-label"><?php echo Lang::T('Username');?>
</label>
                        <div class="col-md-9">
                            <div class="input-group">
                                <?php if ($_smarty_tpl->tpl_vars['_c']->value['country_code_phone'] != '') {?>
                                    <span class="input-group-addon" id="basic-addon1"><i
                                            class="glyphicon glyphicon-phone-alt"></i></span>
                                <?php } else { ?>
                                    <span class="input-group-addon" id="basic-addon1"><i
                                            class="glyphicon glyphicon-user"></i></span>
                                <?php }?>
                                <input type="text" class="form-control" name="username" required
                                    placeholder="<?php if ($_smarty_tpl->tpl_vars['_c']->value['country_code_phone'] != '') {
echo $_smarty_tpl->tpl_vars['_c']->value['country_code_phone'];?>
 <?php echo Lang::T('Phone Number');
} else {
echo Lang::T('Username');
}?>">
                            </div>
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="col-md-3 control-label"><?php echo Lang::T('Full Name');?>
</label>
                        <div class="col-md-9">
                            <input type="text" required class="form-control" id="fullname" name="fullname">
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="col-md-3 control-label"><?php echo Lang::T('Email');?>
</label>
                        <div class="col-md-9">
                            <input type="email" class="form-control" id="email" name="email">
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="col-md-3 control-label"><?php echo Lang::T('Phone Number');?>
</label>
                        <div class="col-md-9">
                            <div class="input-group">
                                <?php if ($_smarty_tpl->tpl_vars['_c']->value['country_code_phone'] != '') {?>
                                    <span class="input-group-addon" id="basic-addon1">+</span>
                                <?php } else { ?>
                                    <span class="input-group-addon" id="basic-addon1"><i
                                            class="glyphicon glyphicon-phone-alt"></i></span>
                                <?php }?>
                                <input type="text" class="form-control" name="phonenumber"
                                    placeholder="<?php if ($_smarty_tpl->tpl_vars['_c']->value['country_code_phone'] != '') {
echo $_smarty_tpl->tpl_vars['_c']->value['country_code_phone'];
}?> <?php echo Lang::T('Phone Number');?>
">
                            </div>
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="col-md-3 control-label"><?php echo Lang::T('Password');?>
</label>
                        <div class="col-md-9">
                            <input type="password" class="form-control" autocomplete="off" required id="password"
                                value="<?php echo rand(000000,999999);?>
" name="password" onmouseleave="this.type = 'password'"
                                onmouseenter="this.type = 'text'">
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="col-md-3 control-label"><?php echo Lang::T('Address');?>
</label>
                        <div class="col-md-9">
                            <textarea name="address" id="address" class="form-control"></textarea>
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="col-md-3 control-label"><?php echo Lang::T('Select Package');?>
</label>
                        <div class="col-md-9">
                            <select class="form-control select2"
                                name="ppln" style="width: 100%" data-placeholder="<?php echo Lang::T('Select Package');?>
...">
						<?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['plans']->value, 'plan');
$_smarty_tpl->tpl_vars['plan']->do_else = true;
if ($_from !== null) foreach ($_from as $_smarty_tpl->tpl_vars['plan']->value) {
$_smarty_tpl->tpl_vars['plan']->do_else = false;
?>
                        <option value="<?php echo $_smarty_tpl->tpl_vars['plan']->value['id'];?>
"><?php echo $_smarty_tpl->tpl_vars['plan']->value['name_plan'];?>
 &bull; <?php echo Lang::moneyFormat($_smarty_tpl->tpl_vars['plan']->value['price']);
if ($_smarty_tpl->tpl_vars['plan']->value['routers']) {?> &bull; <?php echo $_smarty_tpl->tpl_vars['plan']->value['routers'];
}?></option>
						<?php
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
                            </select>
                        </div>
                    </div>
                    
                    <?php if ($_smarty_tpl->tpl_vars['routes']->value['2'] == 'pppoe') {?>
                        <div class="panel-heading">PPPoE Configuration</div>
                        <div class="panel-body">
                            <div class="form-group">
                                <label class="col-md-3 control-label"><?php echo Lang::T('Usernames');?>
 <span class="label label-danger"
                                        id="warning_pppoe_username"></span></label>
                                <div class="col-md-9">
                                    <input type="text" class="form-control" id="pppoe_username" name="pppoe_username"
                                        onkeyup="checkUsername(this, 0)" placeholder="<?php echo Lang::T('PPPoE Username');?>
">
                                    <span class="help-block"><?php echo Lang::T('Not Working with Freeradius Mysql');?>
</span>
                                </div>
                            </div>
                            <div class="form-group">
                                <label class="col-md-3 control-label"><?php echo Lang::T('Password');?>
</label>
                                <div class="col-md-9">
                                    <input type="password" class="form-control" id="pppoe_password" name="pppoe_password"
                                        placeholder="<?php echo Lang::T('PPPoE Password');?>
" onmouseleave="this.type = 'password'"
                                        onmouseenter="this.type = 'text'">
                                </div>
                            </div>
                            <div class="form-group">
                                <label class="col-md-3 control-label">Remote IP <span class="label label-danger"
                                        id="warning_ip"></span></label>
                                <div class="col-md-9">
                                    <input type="text" class="form-control" id="pppoe_ip" name="pppoe_ip"
                                        onkeyup="checkIP(this, 0)" placeholder="Remote IP">
                                    <span class="help-block"><?php echo Lang::T('Not Working with Freeradius Mysql');?>
</span>
                                </div>
                            </div>
                        </div>
                    <?php }?>
                    <div class="panel-heading"></div>
                    <div class="panel-body">
                        <div class="form-group">
                            <label class="col-md-3 control-label"><?php echo Lang::T('Send Welcome Message');?>
</label>
                            <div class="col-md-9">
                                <label class="switch">
                                    <input type="checkbox" id="send_welcome_message" value="1" name="send_welcome_message">
                                    <span class="slider"></span>
                                </label>
                            </div>
                        </div>
                        <div class="form-group" id="method" style="display: none;">
                            <label class="col-md-3 control-label"><?php echo Lang::T('Method');?>
</label>
                            <label class="col-md-3 control-label"><input type="checkbox" name="sms" value="1">
                                <?php echo Lang::T('SMS');?>
</label>
                            <label class="col-md-2 control-label"><input type="checkbox" name="wa" value="1">
                                <?php echo Lang::T('WA');?>
</label>
                            <label class="col-md-2 control-label"><input type="checkbox" name="mail" value="1">
                                <?php echo Lang::T('Email');?>
</label>
                        </div>
                    </div>
                <input type="text" id="service_type" name="service_type" value="<?php if ($_smarty_tpl->tpl_vars['routes']->value['2'] == 'pppoe') {?>PPPoE<?php } else { ?>hotspot<?php }?>" hidden>
            </div>
    <center>
        <button class="btn btn-primary" onclick="return ask(this, 'Continue the process of adding Customer Data?')" type="submit">
            <?php echo Lang::T('Create Account');?>

        </button>
        <br><a href="<?php echo $_smarty_tpl->tpl_vars['_url']->value;?>
customers" class="btn btn-link"><?php echo Lang::T('Cancel');?>
</a>
    </center>
        </div>
    </div>
</form>


    <?php echo '<script'; ?>
>
        // Fungsi dari edit.tpl untuk validasi Username PPPoE (onkeyup)
        function checkUsername(obj, id) {
            var username = obj.value;
            $.post(APP_URL + '/customers/checkUsername', {
                username: username,
                id: id
            }).done(function(data) {
                var warningSpan = document.getElementById('warning_pppoe_username');
                if (data == 'true') {
                    warningSpan.textContent = " {Lang::T('Username has been used')}";
                    warningSpan.style.display = 'inline';
                } else {
                    warningSpan.textContent = "";
                    warningSpan.style.display = 'none';
                }
            }).fail(function(e) {
                console.log(e);
            });
        }

        // Fungsi dari edit.tpl untuk validasi Remote IP (onkeyup)
        function checkIP(obj, id) {
            var ip = obj.value;
            $.post(APP_URL + '/customers/checkIP', {
                ip: ip,
                id: id
            }).done(function(data) {
                var warningSpan = document.getElementById('warning_ip');
                if (data == 'true') {
                    warningSpan.textContent = " {Lang::T('IP has been used')}";
                    warningSpan.style.display = 'inline';
                } else {
                    warningSpan.textContent = "";
                    warningSpan.style.display = 'none';
                }
            }).fail(function(e) {
                console.log(e);
            });
        }

        document.addEventListener('DOMContentLoaded', function() {
            var sendWelcomeCheckbox = document.getElementById('send_welcome_message');
            var methodSection = document.getElementById('method');

            function toggleMethodSection() {
                if (sendWelcomeCheckbox.checked) {
                    methodSection.style.display = 'block';
                } else {
                    methodSection.style.display = 'none';
                }
            }

            toggleMethodSection();

            sendWelcomeCheckbox.addEventListener('change', toggleMethodSection);
            document.querySelector('form').addEventListener('submit', function(event) {
                if (sendWelcomeCheckbox.checked) {
                    var methodCheckboxes = methodSection.querySelectorAll('input[type="checkbox"]');
                    var oneChecked = Array.from(methodCheckboxes).some(function(checkbox) {
                        return checkbox.checked;
                    });

                    if (!oneChecked) {
                        event.preventDefault();
                        alert('Please choose at least one method.');
                        methodSection.focus();
                    }
                }
                
                // Pengecekan tambahan: jika ada warning IP atau Username PPPoE
                var warningIp = document.getElementById('warning_ip');
                var warningPppoeUsername = document.getElementById('warning_pppoe_username');

                if ((warningIp && warningIp.textContent.trim() !== "") || (warningPppoeUsername && warningPppoeUsername.textContent.trim() !== "")) {
                    event.preventDefault();
                    alert('Please fix the warnings for PPPoE Username or Remote IP before continuing.');
                }
            });
        });
    <?php echo '</script'; ?>
>


<?php $_smarty_tpl->_subTemplateRender("file:sections/footer.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
}
}
