<?php
/* Smarty version 4.5.3, created on 2025-12-07 16:16:15
  from '/home/vol8_4/ezyro.com/ezyro_40005848/htdocs/ui/ui/customer/register-rotp.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.5.3',
  'unifunc' => 'content_693537cf029e52_02775006',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '4866e15e3bd5d406c115965ef65cbc61506a0bcf' => 
    array (
      0 => '/home/vol8_4/ezyro.com/ezyro_40005848/htdocs/ui/ui/customer/register-rotp.tpl',
      1 => 1765092699,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
    'file:customer/header-public.tpl' => 1,
    'file:customer/footer-public.tpl' => 1,
  ),
),false)) {
function content_693537cf029e52_02775006 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_subTemplateRender("file:customer/header-public.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

<div class="hidden-xs" style="height:100px"></div>

<div class="row">
    <div class="col-md-2">
    </div>
    <div class="col-md-4">
        <div class="panel panel-primary">
            <div class="panel-heading"><?php echo Lang::T('Registration Info');?>
</div>
            <div class="panel-body">
                <?php $_smarty_tpl->_subTemplateRender(((string)$_smarty_tpl->tpl_vars['_path']->value)."/../pages/Registration_Info.html", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, true);
?>
            </div>
        </div>
    </div>
    <form action="<?php echo Text::url('register');?>
" method="post">
        <div class="col-md-4">
            <div class="panel panel-primary">
                <div class="panel-heading">1. <?php echo Lang::T('Register as Member');?>
</div>
                <div class="panel-body">
                    <div class="form-group">
                        <label>
                            <?php echo Lang::T('Phone Number');?>

                        </label>
                        <div class="input-group">
                            <span class="input-group-addon" id="basic-addon1"><i
                                    class="glyphicon glyphicon-phone-alt"></i></span>
                            <input type="text" class="form-control" name="phone_number"
                                placeholder="<?php if ($_smarty_tpl->tpl_vars['_c']->value['country_code_phone'] != '' || $_smarty_tpl->tpl_vars['_c']->value['registration_username'] == 'phone') {
echo $_smarty_tpl->tpl_vars['_c']->value['country_code_phone'];?>
 <?php echo Lang::T('Phone Number');
} else {
echo Lang::T('Phone Number');
}?>"
                                inputmode="numeric" pattern="[0-9]*">
                        </div>
                    </div>
                    <div class="btn-group btn-group-justified mb15">
                        <div class="btn-group">
                            <a href="<?php echo Text::url('login');?>
" class="btn btn-warning"><?php echo Lang::T('Cancel');?>
</a>
                        </div>
                        <div class="btn-group">
                            <button class="btn btn-success" type="submit"><?php echo Lang::T('Request OTP');?>
</button>
                        </div>
                    </div>
                    <br>
                    <center>
                        <a href="javascript:showPrivacy()">Privacy</a>
                        &bull;
                        <a href="javascript:showTaC()">T &amp; C</a>
                    </center>
                </div>
            </div>
        </div>
    </form>
</div>

<?php $_smarty_tpl->_subTemplateRender("file:customer/footer-public.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
}
}
